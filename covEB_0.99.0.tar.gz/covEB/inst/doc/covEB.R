### R code from vignette source 'covEB.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: covEB.Rnw:30-31
###################################################
options(width=60)


###################################################
### code chunk number 2: covEB.Rnw:38-49
###################################################
 library(mvtnorm)
 library(covEB)
 library(igraph)
 	sigma <- matrix(c(4,2,2,3), ncol=2)
	x <- rmvnorm(n=500, mean=c(1,2), sigma=sigma)
 
 	samplecov<-cov(x)
 
 	test<-covEB(samplecov,delta=0.05,shift=0.025,startlambda=0.4)




